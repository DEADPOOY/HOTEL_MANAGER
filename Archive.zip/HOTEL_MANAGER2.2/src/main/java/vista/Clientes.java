/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author deadpooy
 */

import dao.ClienteDAO;
import modelo.Cliente;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class Clientes extends JPanel {

    private JTable tablaClientes;
    private DefaultTableModel modeloTabla;
    private ClienteDAO clienteDAO;
    private List<Cliente> listaInterna;

    public Clientes() {
        clienteDAO = new ClienteDAO();
        setBackground(new Color(0xF7, 0xF5, 0xF0));
        setLayout(new BorderLayout(20, 20));
        setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));

        JPanel mainCard = new JPanel(new BorderLayout());
        mainCard.setBackground(Color.WHITE);
        mainCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xE2, 0xE8, 0xF0), 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        // Columnas limpias sin ID Cliente expuesto
        String[] columnas = {"N°", "Nombre Completo", "Teléfono"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        tablaClientes = new JTable(modeloTabla);
        tablaClientes.setRowHeight(30);
        tablaClientes.getTableHeader().setReorderingAllowed(false); // Bloqueado
        tablaClientes.getTableHeader().setBackground(new Color(0x1A, 0x27, 0x44));
        tablaClientes.getTableHeader().setForeground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(tablaClientes);
        mainCard.add(scroll, BorderLayout.CENTER);
        add(mainCard, BorderLayout.CENTER);

        cargarClientes();
    }

    private void cargarClientes() {
        modeloTabla.setRowCount(0);
        
        listaInterna = clienteDAO.obtenerTodos(); 
        
        int index = 1;
        for (Cliente c : listaInterna) {
            Object[] fila = {
                index,
                c.getNomCliente(),  
                c.getNumCliente()
            };
            modeloTabla.addRow(fila);
            index++;
        }
    }
}